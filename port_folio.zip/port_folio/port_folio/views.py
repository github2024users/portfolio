from django.shortcuts import render, redirect
from profiledetails.models import Projects, contactus

def homepage(request):
    insert_data=Projects.objects.all()
    data={
        "insert_data":insert_data
    }
    return render(request, "index.html",data)

def Contactus(request):
    n=""
    contact=contactus.objects.all()
    if request.method=="POST":
        name=request.POST.get('name')
        email=request.POST.get('email')
        phone=request.POST.get('phone')
        message=request.POST.get('message')
        en=contactus(name=name, email=email, phone=phone, desc=message)
        en.save()
        n="message sent successfully"
        return redirect('/?success=true') # to prevent the duplicate submission of data during refresh
    return render(request,"index.html",{"n":n})