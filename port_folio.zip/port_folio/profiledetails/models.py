from django.db import models
from django.utils import timezone

class Projects(models.Model):
    project_title = models.CharField(max_length=200)
    project_series = models.CharField(max_length=200)
    project_technology = models.TextField()
    project_desc = models.TextField()
    
    def __str__(self):
        return self.project_title
    
    class Meta:
        verbose_name_plural = "Projects"

class contactus(models.Model):
    name = models.CharField(max_length=150)
    email = models.EmailField(max_length=254)
    phone = models.CharField(max_length=50)
    desc = models.TextField()  # Keep as 'desc' to match your existing database
    created_at = models.DateTimeField(default=timezone.now)  # Use default instead of auto_now_add
    
    def __str__(self):
        return f"{self.name} - {self.email}" 
    
    class Meta:
        verbose_name_plural = "Contact Messages" # this is use to make django admin class name attractive, it will looke like "concat message" instead of "contactus"
        ordering = ['-created_at']  #this will orderise the data in descending order, newest at the top and oldest at the below